﻿angular.module('blogapp',["firebase"]).factory('DataService', function ($http) {
    var dataservice;
   
    return dataservice;
});